﻿
// CapturerDlg.cpp: 实现文件
//

#include "pch.h"
#include "framework.h"
#include "Capturer.h"
#include "CapturerDlg.h"
#include "afxdialogex.h"
#include "Sniffer.h"
#include <locale.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif
Sniffer sniffer;


 char *MB = (char *)malloc(BUFFER_SIZE);
// 用于应用程序“关于”菜单项的 CAboutDlg 对话框

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

// 实现
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CCapturerDlg 对话框



CCapturerDlg::CCapturerDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_CAPTURER_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CCapturerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_ID, CEDIT_ID);
	DDX_Control(pDX, IDC_EDIT_NUM, CEDIT_NUM);
}

BEGIN_MESSAGE_MAP(CCapturerDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_RUN, &CCapturerDlg::OnBnClickedRun)
	ON_BN_CLICKED(IDC_OPEN_FILE, &CCapturerDlg::OnBnClickedOpenFile)
	ON_BN_CLICKED(IDC_SAVE_FILE, &CCapturerDlg::OnBnClickedSaveFile)
END_MESSAGE_MAP()


// CCapturerDlg 消息处理程序

BOOL CCapturerDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// 将“关于...”菜单项添加到系统菜单中。

	// IDM_ABOUTBOX 必须在系统命令范围内。
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// 设置此对话框的图标。  当应用程序主窗口不是对话框时，框架将自动
	//  执行此操作
	SetIcon(m_hIcon, TRUE);			// 设置大图标
	SetIcon(m_hIcon, FALSE);		// 设置小图标

	// TODO: 在此添加额外的初始化代码
	

	CEDIT_ID.SetCueBanner((LPCWSTR)TEXT("网卡ID:"));
	CEDIT_NUM.SetCueBanner((LPCWSTR)TEXT("捕获数量:"));
	SetDlgItemTextA(AfxGetMainWnd()->m_hWnd,IDC_STATIC_INTERFACE, sniffer.getAlldevs());
	return TRUE;  // 除非将焦点设置到控件，否则返回 TRUE
}

void CCapturerDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// 如果向对话框添加最小化按钮，则需要下面的代码
//  来绘制该图标。  对于使用文档/视图模型的 MFC 应用程序，
//  这将由框架自动完成。

void CCapturerDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 用于绘制的设备上下文

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 使图标在工作区矩形中居中
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// 绘制图标
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

//当用户拖动最小化窗口时系统调用此函数取得光标
//显示。
HCURSOR CCapturerDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void CCapturerDlg::OnBnClickedRun()
{
	// TODO: 在此添加控件通知处理程序代码
	char  aIP[17];
	int vCount = -1;
	TCHAR aNetcard[8] = { 0 };//网卡号
	int vNetcard = 0;
	packet_number = 1;
	memset(s, 0, BUFFER_SIZE);
	GetDlgItemText(IDC_EDIT_ID, aNetcard, 8);
	vNetcard = _wtoi(aNetcard);
	sniffer.findDevices(vNetcard);
	memset(aIP, 0, 17);
	GetDlgItemTextA(AfxGetApp()->m_pMainWnd->m_hWnd ,IDC_IPADDRESS, aIP, 16);
	sniffer.filterIPAddr(aIP);
	char aBuf[64] = { 0 };
	sprintf(aBuf, "正在监听 %s...", sniffer.getStatus());
	SetDlgItemTextA(AfxGetApp()->m_pMainWnd->m_hWnd ,IDC_STATUS, aBuf);
	TCHAR aCount[8] = { 0 };
	GetDlgItemText(IDC_EDIT_NUM, aCount, 8);
	vCount = _wtoi(aCount);
	sniffer.run(vCount);
	SetDlgItemText(IDC_SHOW, (LPCTSTR)sniffer.getBuffer());
	SetDlgItemText(IDC_STATUS, TEXT(""));

}


void CCapturerDlg::OnBnClickedOpenFile()
{
	TCHAR szFilter[] = _T("文本文件(*.txt)|*.txt|所有文件(*.*)|*.*||");
	// 构造打开文件对话框   
	CFileDialog fileDlg(TRUE, _T("txt"), NULL, 0, szFilter, this);
	CString strFilePath;

	// 显示打开文件对话框  

	if (IDOK == fileDlg.DoModal())
	{
		// 如果点击了文件对话框上的“打开”按钮，则将选择的文件路径显示到编辑框里   
		strFilePath = fileDlg.GetPathName();
	
	}
	ifstream infile;
	infile.open(strFilePath, ios::in);

	infile.seekg(0, std::ios::end);
	int  length = infile.tellg();
	infile.seekg(0, std::ios::beg);
	char *buffer = new char[length];
	memset(buffer, 0, length);
	infile.read(buffer, length);
	SetDlgItemTextA(AfxGetApp()->m_pMainWnd->m_hWnd ,IDC_SHOW, buffer);
	infile.close();
	delete buffer;
	

}


void CCapturerDlg::OnBnClickedSaveFile()
{
	setlocale(LC_ALL, "chs");
	TCHAR szFilter[] = _T("文本文件(*.txt)|*.txt|所有文件(*.*)|*.*||");
	// 构造打开文件对话框   
	CFileDialog fileDlg(TRUE, _T("txt"), NULL, 0, szFilter, this);
	CString strFilePath;
	strFilePath = fileDlg.GetPathName();
	if (IDOK == fileDlg.DoModal())
	{
		strFilePath = fileDlg.GetPathName();
	}
	ofstream outfile(strFilePath,  ios::out);

	wcstombs(MB, sniffer.getBuffer(), BUFFER_SIZE);
	outfile << MB;
	outfile.close();


}
