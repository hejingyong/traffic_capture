#pragma once

#include "pch.h"


static int  packet_number;
static TCHAR  s[BUFFER_SIZE];

static TCHAR usrcip[40] = { 0 };
static TCHAR udestip[40] = { 0 };
static char srcip[40] = { 0 };
static char destip[40] = { 0 };


class Sniffer 
{
private:
	pcap_if_t *d = NULL;
	pcap_if_t	*alldevs = NULL;
	pcap_if_t	*_alldevs = NULL;

	const static int head = 54;
	TCHAR errbuf[PCAP_ERRBUF_SIZE] = { 0 };
	struct bpf_program fcode;
	int i,k;
	pcap_t *adhandle;
	

struct ethernet_header
{
	u_char ether_dhost[6];  /*Ŀ����̫��ַ*/
	u_char ether_shost[6];  /*Դ��̫����ַ*/
	u_char ether_type;      /*��̫������*/
}ethernet_header;
typedef u_int in_addr_t;
struct ip_header
{
	u_char ip_header_length : 4,
		ip_version : 4;
	u_char ip_tos;         /*��������Differentiated Services  Field*/
	u_short ip_length;  /*�ܳ���Total Length*/
	u_short ip_id;         /*��ʶidentification*/
	u_short ip_off;        /*Ƭƫ��*/
	u_char ip_ttl;            /*����ʱ��Time To Live*/
	u_char ip_protocol;        /*Э�����ͣ�TCP����UDPЭ�飩*/
	u_short ip_checksum;  /*�ײ������*/
	struct in_addr  ip_source_address; /*ԴIP*/
	struct in_addr  ip_destination_address; /*Ŀ��IP*/
}ip_header;
struct tcp_header
{
	u_short tcp_source_port;		  //Դ�˿ں�
	u_short tcp_destination_port;	//Ŀ�Ķ˿ں�
	u_int tcp_acknowledgement;	//���
	u_int tcp_ack;	//ȷ�Ϻ��ֶ�
	u_char tcp_reserved : 4,
		tcp_offset : 4;
	u_char tcp_flags;
	u_short tcp_windows;	//�����ֶ�
	u_short tcp_checksum;	//�����
	u_short tcp_urgent_pointer;	//����ָ���ֶ�
}tcp_header;
struct udp_header {
	u_short udp_source_port;		  //Դ�˿ں�
	u_short udp_destination_port;	//Ŀ�Ķ˿ں�
	u_short packet_length;		  //���ݰ�����
	u_short check_sum;	//����

}udp_header;
struct icmp_header {
	u_char type;		  //����
	u_char code;	//����
	u_short check_sum;		  //16λУ���,
	u_char id;	//ʶ���
	u_char seq;	//�������к�
	u_short timestamp;	//ʱ���

}icmp_header;

public:
	  char  *getAlldevs();
	  void findDevices(int vNetcard);
	  void filterIPAddr(char * aIp);
	  static void icmp_protocol_packet_callback(u_char *argument, const struct pcap_pkthdr*
		packet_header, const u_char* packet_content);
	  static void udp_protocol_packet_callback(u_char *argument, const struct pcap_pkthdr*
		packet_header, const u_char* packet_content);
	  static void tcp_protocol_packet_callback(u_char *argument, const struct pcap_pkthdr*
		packet_header, const u_char* packet_content);
	  static void ip_protocol_packet_callback(u_char *argument, const struct pcap_pkthdr*
		packet_header, const u_char* packet_content);
	  static void ethernet_protocol_packet_callback(u_char *argument, const struct pcap_pkthdr *
		packet_header, const u_char* packet_content);
	  void ErrorBox(TCHAR *e);
	  char *getStatus();
	  void run(int vCount);
	  TCHAR * getBuffer();


};